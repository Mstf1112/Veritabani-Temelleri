CREATE TABLE incelemeler (
    incelemeID int PRIMARY KEY,
    pozitifInceleme text,
    negatifInceleme text
);