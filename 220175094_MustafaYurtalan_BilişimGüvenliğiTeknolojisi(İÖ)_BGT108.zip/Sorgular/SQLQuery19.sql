INSERT INTO earlyaccess (id, cikisTarihi, cikisTarihiYaklasanlar, cikanlar)
VALUES
    (1, '2023-07-01', 'Oyun A, Oyun B', 'Oyun C'),
    (2, '2023-08-15', 'Oyun D', 'Oyun E, Oyun F'),
    (3, '2023-09-30', 'Oyun G, Oyun H', 'Oyun I');
