INSERT INTO api (id, uygulamaAdi, apiAnahtari, yetkilendirilmisMetodlar, sonKullanmaTarihi)
VALUES
    (1, 'Uygulama A', '123abc', 'GET, POST', '2023-12-31'),
    (2, 'Uygulama B', 'xyz456', 'GET, PUT, DELETE', '2023-10-15'),
    (3, 'Uygulama C', '789def', 'GET, POST, PUT, DELETE', '2024-02-28');
