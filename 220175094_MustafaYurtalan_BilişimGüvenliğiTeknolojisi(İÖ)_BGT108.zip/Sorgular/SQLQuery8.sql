SELECT TOP 1 *
FROM fiyatlar
ORDER BY donusturulmusfiyat ASC;
