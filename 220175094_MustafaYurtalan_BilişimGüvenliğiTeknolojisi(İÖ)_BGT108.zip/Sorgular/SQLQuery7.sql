INSERT INTO fiyatlar (parabirimi, suankifiyat, donusturulmusfiyat)
VALUES
    ('USD', 10.99, 78.25),
    ('EUR', 8.75, 98.50),
    ('TRY', 100.00, 100.00),
    ('GBP', 12.50, 65.75);