INSERT INTO oyunbilgileri (oyunID, oyunAdi, gelistirici, yayinci, desteklenenSistem, sonGuncellemeTarihi, cikisYili)
VALUES
    (1, 'Oyun A', 'Gelistirici A', 'Yayinci A', 'PC', '2022-05-15', 2021),
    (2, 'Oyun B', 'Gelistirici B', 'Yayinci B', 'PS4, Xbox One', '2023-01-20', 2022),
    (3, 'Oyun C', 'Gelistirici C', 'Yayinci C', 'PC, Nintendo S