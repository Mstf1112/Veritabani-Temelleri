CREATE TABLE topluluk_tablosu (
    toplulukID int PRIMARY KEY,
    kartlar varchar(100),
    rozetler varchar(100)
);
