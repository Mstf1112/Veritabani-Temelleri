CREATE TABLE ek_paketler (
    paketID int PRIMARY KEY,
    paketAdi varchar(100),
    paketFiyati decimal(10, 2),
    cikisTarihi date
);
