INSERT INTO apiinfo (id, sistemGereksinimleri, clientIcon, logo, metacritic)
VALUES
    (1, 'Minimum: Windows 10, 8 GB RAM, NVIDIA GTX 1050, 50 GB bo� disk alan�', 'client1.png', 'logo1.png', 85),
    (2, 'Minimum: macOS 10.15, 16 GB RAM, AMD Radeon Pro 5500 XT, 100 GB bo� disk alan�', 'client2.png', 'logo2.png', 90),
    (3, 'Minimum: Android 7.0, 4 GB RAM, Qualcomm Snapdragon 845, 2 GB bo� depolama alan�', 'client3.png', 'logo3.png', 80);
