CREATE TABLE oyuncusayisi (
    id int PRIMARY KEY,
    anlikOyuncu int,
    gunlukEnYuksekOyuncu int,
    tumZamanlardakiEnYuksekOyuncu int,
    trendOyun varchar(100)
);
