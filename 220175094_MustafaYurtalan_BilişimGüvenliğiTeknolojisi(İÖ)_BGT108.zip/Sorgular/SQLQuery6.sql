CREATE TABLE fiyatlar (
    parabirimi varchar(50),
    suankifiyat decimal(10, 2),
    donusturulmusfiyat decimal(10, 2)
);