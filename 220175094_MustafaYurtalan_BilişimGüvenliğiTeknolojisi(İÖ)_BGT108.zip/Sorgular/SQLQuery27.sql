CREATE TABLE apiinfo (
    id int PRIMARY KEY,
    sistemGereksinimleri varchar(100),
    clientIcon varchar(100),
    logo varchar(100),
    metacritic int
);
