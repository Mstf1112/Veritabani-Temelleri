INSERT INTO topluluk_tablosu (toplulukID, kartlar, rozetler)
VALUES
    (1, 'Kart A, Kart B, Kart C', 'Rozet X, Rozet Y'),
    (2, 'Kart D, Kart E', 'Rozet Z'),
    (3, 'Kart F', 'Rozet P, Rozet Q, Rozet R');
