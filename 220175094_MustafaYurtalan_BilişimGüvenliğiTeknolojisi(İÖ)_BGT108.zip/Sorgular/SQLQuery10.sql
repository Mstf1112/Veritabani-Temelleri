INSERT INTO ek_paketler (paketID, paketAdi, paketFiyati, cikisTarihi)
VALUES
    (1, 'Paket A', 9.99, '2023-05-15'),
    (2, 'Paket B', 19.99, '2023-06-01'),
    (3, 'Paket C', 14.99, '2023-04-20');