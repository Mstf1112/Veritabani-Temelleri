INSERT INTO oyuncusayisi (id, anlikOyuncu, gunlukEnYuksekOyuncu, tumZamanlardakiEnYuksekOyuncu, trendOyun)
VALUES
    (1, 1000, 1500, 2000, 'Oyun A'),
    (2, 2000, 2500, 3000, 'Oyun B'),
    (3, 500, 1000, 1500, 'Oyun C');
