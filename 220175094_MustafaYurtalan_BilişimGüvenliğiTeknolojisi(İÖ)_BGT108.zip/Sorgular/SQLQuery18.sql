CREATE TABLE earlyaccess (
    id int PRIMARY KEY,
    cikisTarihi date,
    cikisTarihiYaklasanlar varchar(100),
    cikanlar varchar(100)
);
