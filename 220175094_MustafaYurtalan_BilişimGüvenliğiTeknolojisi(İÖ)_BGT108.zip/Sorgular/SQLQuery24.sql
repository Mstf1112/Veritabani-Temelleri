CREATE TABLE api (
    id int PRIMARY KEY,
    uygulamaAdi varchar(100),
    apiAnahtari varchar(100),
    yetkilendirilmisMetodlar varchar(100),
    sonKullanmaTarihi date
);
